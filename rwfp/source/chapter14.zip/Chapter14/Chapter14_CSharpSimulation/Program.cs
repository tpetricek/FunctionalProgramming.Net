﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Simulation_CSharp
{
  class Program
  {
    static void Main(string[] args)
    {
      Application.Run(new MainForm());
    }
  }
}
